/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: suhpark <joushin@student.42seoul.k>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/21 20:16:13 by suhpark           #+#    #+#             */
/*   Updated: 2022/04/21 20:55:33 by suhpark          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned char	*src2;
	unsigned int	src_len;

	src2 = (unsigned char *)src;
	i = 0;
	src_len = 0;
	if (size == 0)
		return (src_len);
	while (src2[src_len] != '\0')
		src_len++;
	while (src2[i] != '\0' && i < size -1)
	{
		dest[i] = src2[i];
		i++;
	}
	return (src_len);
}
/*#include<stdio.h>
int	main()
{
	printf("ex10\n");
    char ex10_src2[] = "hello my name is hunpark!";
	char ex10_dest[50];
    printf("src : %s, size = 5\n", ex10_src2);
	printf("ft_strlcpy : %d\n", ft_strlcpy(ex10_dest, ex10_src2, 5));
	printf("dest : %s\n\n", ex10_dest);
}*/
