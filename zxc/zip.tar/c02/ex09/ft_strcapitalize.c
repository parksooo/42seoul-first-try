/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: suhpark <joushin@student.42seoul.k>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/20 12:31:30 by suhpark           #+#    #+#             */
/*   Updated: 2022/04/21 19:53:49 by suhpark          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*mini(char *str)
{
	int	a;

	a = 0;
	while (str [a] != '\0')
	{
		if (str [a] >= 'A' && str [a] <= 'Z')
			str [a] = str [a] +32;
		a++;
	}
	return (str);
}

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	mini(str);
	if (str [i] >= 'a' && str [i] <= 'z')
		str [i] = str [i] - 32;
	i = 1;
	while (str [i] != '\0')
	{
		if (!((str [i] >= 'a' && str [i] <= 'z')
				|| (str [i] >= '0' && str [i] <= '9')
				|| (str [i] >= 'A' && str [i] <= 'Z')))
			if (str [i + 1] >= 'a' && str [i + 1] <= 'z')
				str [i + 1] = str [i +1] - 32;
		i++;
	}
	return (str);
}
/*#include <stdio.h>
int	main()
{
	printf("ex09\n");
    char ex09_str[] = 
	"sLlUt, cNmmEnt tu VAS ? `42moTs EQarEQnte-deWx; cOInRuTntT+et+Wn";
    printf("before str : %s\n", ex09_str);
	printf("after str : %s\n\n", ft_strcapitalize(ex09_str));
}*/
